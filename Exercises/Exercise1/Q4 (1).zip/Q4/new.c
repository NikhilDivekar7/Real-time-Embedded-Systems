#define _GNU_SOURCE
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <unistd.h>
#include <time.h>
#include <syslog.h>
#include <math.h>
#include <sys/param.h>
#include <stdint.h>
#include <semaphore.h>

#define NUM_THREADS (1)
#define NUM_CPUS (1)

#define NSEC_PER_SEC (1000000000)
#define NSEC_PER_MSEC (1000000)
#define NSEC_PER_MICROSEC (1000)

#define DELAY_TICKS (1)
#define ERROR (-1)
#define OK (0)

unsigned int idx = 0, jdx = 1;
uint32_t seqIterations = 47;
//uint32_t reqIterations = 1400000;
uint32_t fib = 0, fib0 = 0, fib1 = 1;

#define FIB_TEST(seqCnt, iterCnt) \
for(idx=0; idx < iterCnt; idx++) \
{ \
	while(jdx < seqCnt) \
	{ \
		if (jdx == 0) \
		{ \
			fib = 1; \
		} \
		else \
		{ \
			fib0 = fib1; \
			fib1 = fib; \
			fib = fib0 + fib1; \
		} \
		jdx++; \
	} \
}

pthread_t thread1, thread2;
pthread_attr_t thread1_attr, thread2_attr, main_attr;
int rt_max_prio, rt_min_prio;
int abortTest1=0;
int abortTest2=0;

struct sched_param nrt_param;
struct sched_param thread1_param;
struct sched_param thread2_param;
struct sched_param main_param;
	
sem_t sem1, sem2;
struct timespec start_time = {0,0};
struct timespec stop_time = {0, 0};
struct timespec time_diff = {0, 0};

int delta_t(struct timespec *stop, struct timespec *start, struct timespec *delta_t)
{
	int dt_sec=stop->tv_sec - start->tv_sec;
	int dt_nsec=stop->tv_nsec - start->tv_nsec;

	if(dt_sec >= 0)
	{
		if(dt_nsec >= 0)
		{
			delta_t->tv_sec=dt_sec;
			delta_t->tv_nsec=dt_nsec;
		}
		else
		{
			delta_t->tv_sec=dt_sec-1;
			delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
		}
	}
	else
	{
		if(dt_nsec >= 0)
			{
				delta_t->tv_sec=dt_sec;
				delta_t->tv_nsec=dt_nsec;
			}
			else
			{
				delta_t->tv_sec=dt_sec-1;
				delta_t->tv_nsec=NSEC_PER_SEC+dt_nsec;
			}
	}
	return 1;
}

void print_scheduler(void)
{
	int schedType;

	schedType = sched_getscheduler(getpid());

	switch(schedType)
	{
		case SCHED_FIFO:
		printf("Pthread Policy is SCHED_FIFO\n");
		break;
 
		case SCHED_OTHER:
		printf("Pthread Policy is SCHED_OTHER\n");
 		break;
 
		case SCHED_RR:
		printf("Pthread Policy is SCHED_OTHER\n");
		break;
 
		default:
 		printf("Pthread Policy is UNKNOWN\n");
 	}
}

void *fib10(void *threadid)
{
	while(!abortTest1)
	{
		sem_wait(&sem1);
		FIB_TEST(seqIterations, 1100000);
		clock_gettime(CLOCK_REALTIME, &stop_time);
	 	delta_t(&stop_time, &start_time, &time_diff);
	 	printf("Thread 1, Fib10, Time stamp: %lf msec\n", (double)((double)time_diff.tv_nsec / NSEC_PER_MSEC));
	}
}

void *fib20(void *threadid)
{
	while(!abortTest2)
	{
		sem_wait(&sem2);
		FIB_TEST(seqIterations, 2200000);
		clock_gettime(CLOCK_REALTIME, &stop_time);
		delta_t(&stop_time, &start_time, &time_diff);
		printf("Thread 2, Fib20, Time stamp: %lf msec\n", (double)((double)time_diff.tv_nsec / NSEC_PER_MSEC));
	}
}
	
int main (void)
{
	int rc, scope,i;
	sem_init (&sem1, 0, 1);
	sem_init (&sem2, 0, 1);

	printf("Before:\n");
	print_scheduler();

	rt_max_prio = sched_get_priority_max (SCHED_FIFO);
	rt_min_prio = sched_get_priority_min (SCHED_FIFO);
	main_param.sched_priority = rt_max_prio;

	pthread_attr_init (&thread1_attr);
	pthread_attr_init (&thread2_attr);
	pthread_attr_setinheritsched (&thread1_attr, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy (&thread1_attr, SCHED_FIFO);
	pthread_attr_setinheritsched (&thread2_attr, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy (&thread2_attr, SCHED_FIFO);
	pthread_attr_setschedparam(&thread1_attr,&thread1_param);
 	pthread_attr_setschedparam (&thread2_attr,&thread2_param);

	thread1_param.sched_priority = rt_max_prio-1;
	thread2_param.sched_priority = rt_max_prio-2;

	rc=sched_setscheduler(getpid(), SCHED_FIFO, &main_param);
	printf("After:\n");
	print_scheduler();

	pthread_attr_getscope (&thread1_attr, &scope);
	if(scope == PTHREAD_SCOPE_SYSTEM)
	printf("PTHREAD SCOPE SYSTEM\n");
	else if (scope == PTHREAD_SCOPE_PROCESS)
	printf("PTHREAD SCOPE PROCESS\n");
	else
	printf("PTHREAD SCOPE UNKNOWN\n");

	printf("min priority = %d\n", rt_min_prio);
	printf("max priority = %d\n", rt_max_prio);
 

 	clock_gettime(CLOCK_REALTIME, &start_time);
 	pthread_create(&thread1, &thread1_attr,fib10 , (void *)0);
 	pthread_create(&thread2, &thread2_attr,fib20 , (void *)0);

	usleep(20000);
	sem_post(&sem1);
	usleep(20000);
	sem_post(&sem1);
	usleep(10000);
	abortTest2 = 1;
	sem_post(&sem2);
	usleep(10000);
	sem_post(&sem1);
	usleep(20000);
	abortTest1 = 1;
	sem_post(&sem1);
	usleep(10000);
	usleep(10000);

	clock_gettime(CLOCK_REALTIME, &stop_time);
	delta_t(&stop_time, &start_time, &time_diff);
	printf("Total duration: %lf msec\n", (double)((double)time_diff.tv_nsec / NSEC_PER_MSEC));

	pthread_join(thread1,NULL);
	pthread_join(thread2,NULL);

	sem_destroy(&sem1);
	sem_destroy(&sem2);

	printf("TEST COMPLETE\n");
}


