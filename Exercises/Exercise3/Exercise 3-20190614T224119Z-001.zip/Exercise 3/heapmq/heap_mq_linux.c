/****************************************************************************/
/* Message queue application adapted from Vxworks to Linux. Vxworks Code    */
/* wass written by Sam Siewert - 10/14/97                                   */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* Author - Mason Darveaux                                                  */
/*                                                                          */
/****************************************************************************/




#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <mqueue.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define SNDRCV_MQ "/send_receive_mq"
#define ERROR (-1)

struct mq_attr mq_attr;
static mqd_t mymq;

pthread_t thread_receive;
pthread_t thread_send;

pthread_attr_t receive_attr;
pthread_attr_t send_attr;
pthread_attr_t main_sched_attr;

struct sched_param receive_param;
struct sched_param send_param;
struct sched_param main_param;


int rt_max_prio;

void* receiver(void *threadp)
{
  char buffer[sizeof(void *)+sizeof(int)];
  void *buffptr;
  int prio;
  int nbytes;
  int count = 0;
  int id;

  while(1) {

    /* read oldest, highest priority msg from the message queue */

    //printf("Reading %ld bytes\n", sizeof(void *));

    printf("Waiting for bytes to receive\n");

    if((nbytes = mq_receive(mymq, buffer, (size_t)(sizeof(void *)+sizeof(int)), &prio)) == ERROR)
/*
    if((nbytes = mq_receive(mymq, (void *)&buffptr, (size_t)sizeof(void *), &prio)) == ERROR)
*/
    {
      perror("mq_receive");
    }
    else
    {
      memcpy(&buffptr, buffer, sizeof(void *));
      memcpy((void *)&id, &(buffer[sizeof(void *)]), sizeof(int));
      printf("receive: ptr msg 0x%X received with priority = %d, length = %d, id = %d\n", buffptr, prio, nbytes, id);

      printf("contents of ptr = \n%s\n", (char *)buffptr);

      free(buffptr);

      printf("heap space memory freed\n");

      pthread_exit(NULL);

    }

  }

}

static char imagebuff[4096];

void* sender(void *threadp)
{
  char buffer[sizeof(void *)+sizeof(int)];
  void *buffptr;
  int prio;
  int nbytes;
  int id = 999;


  while(1) {

    /* send malloc'd message with priority=30 */

    buffptr = (void *)malloc(sizeof(imagebuff));
    strcpy(buffptr, imagebuff);
    printf("Message to send = %s\n", (char *)buffptr);

    printf("Sending %ld bytes\n", sizeof(buffptr)+sizeof(int));

    memcpy(buffer, &buffptr, sizeof(void *));
    memcpy(&(buffer[sizeof(void *)]), (void *)&id, sizeof(int));

    if((nbytes = mq_send(mymq, buffer, (size_t)(sizeof(void *)+sizeof(int)), 30)) == ERROR)
    {
      perror("mq_send");
    }
    else
    {
      printf("send: message ptr 0x%X successfully sent\n", buffptr);
    }

    pthread_exit(NULL);

    //replace task delay with sleep function
    usleep(100000);

  }

}


static int sid, rid;

void main(void)
{
  int i, j;
  int rc;
  char pixel = 'A';

  for(i=0;i<4096;i+=64) {
    pixel = 'A';
    for(j=i;j<i+64;j++) {
      imagebuff[j] = (char)pixel++;
    }
    imagebuff[j-1] = '\n';
  }
  imagebuff[4095] = '\0';
  imagebuff[63] = '\0';

  printf("buffer =\n%s\n", imagebuff);

  /* setup common message q attributes */
  mq_attr.mq_maxmsg = 100;
  mq_attr.mq_msgsize = sizeof(void *)+sizeof(int);

  mq_attr.mq_flags = 0;

  mymq = mq_open(SNDRCV_MQ, O_CREAT|O_RDWR, S_IRWXU, &mq_attr);

  if(mymq < 0)
    perror("mq_open");
  else
  {
    printf("opened mq\n");
  }

  rt_max_prio = sched_get_priority_max(SCHED_FIFO);

  //receiver runs at a higher priority than sender
  main_param.sched_priority = rt_max_prio;
  receive_param.sched_priority = rt_max_prio-1;
  send_param.sched_priority = rt_max_prio-2;

  pthread_attr_init(&main_sched_attr);
  pthread_attr_setinheritsched(&main_sched_attr, PTHREAD_EXPLICIT_SCHED);
  pthread_attr_setschedpolicy(&main_sched_attr, SCHED_FIFO);

  pthread_attr_init(&receive_attr);
  pthread_attr_setinheritsched(&receive_attr, PTHREAD_EXPLICIT_SCHED);
  pthread_attr_setschedpolicy(&receive_attr, SCHED_FIFO);

  pthread_attr_init(&send_attr);
  pthread_attr_setinheritsched(&send_attr, PTHREAD_EXPLICIT_SCHED);
  pthread_attr_setschedpolicy(&send_attr, SCHED_FIFO);

  rc=sched_setscheduler(getpid(), SCHED_FIFO, &main_param);

  if (rc)
  {
    printf("ERROR; sched_setscheduler rc is %d\n", rc); perror(NULL); exit(-1);
  }


  pthread_attr_setschedparam(&main_sched_attr, &main_param);
  pthread_attr_setschedparam(&receive_attr, &receive_param);
  pthread_attr_setschedparam(&send_attr, &send_param);



    rc = pthread_create(&thread_receive,   // pointer to thread descriptor
                   &receive_attr,     // use defined attributes
                   receiver, // thread function entry point
                   NULL // parameters to pass in
                  );


    if (rc)
    {
        printf("ERROR; pthread_create() rc for thread_receive is %d\n", rc);
        perror(NULL);
        exit(-1);
    }
        printf("Receive thread created\n");

    rc = pthread_create(&thread_send,   // pointer to thread descriptor
                   &send_attr,     // use defined attributes
                   sender, // thread function entry point
                   NULL // parameters to pass in
                  );

    if (rc)
    {
        printf("ERROR; pthread_create() rc for thread_send is %d\n", rc);
        perror(NULL);
        exit(-1);
    }

      printf("Send thread created\n");


    //wait for receive thread to terminate
    pthread_join(thread_receive, NULL);

    //wait for send thread to terminate
    pthread_join(thread_send, NULL);

    //close the message queue
    mq_close(mymq);





}
