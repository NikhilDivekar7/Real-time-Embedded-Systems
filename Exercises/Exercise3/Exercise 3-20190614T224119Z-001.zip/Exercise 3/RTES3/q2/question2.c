#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>

#define count 50

pthread_mutex_t my_mutex;

struct timespec;

struct altitude_struct
{
    double x;
    double y;
    double z;
    double acceleration;
    double roll;
    double pitch;
    double yaw;
    struct timespec time;
};

struct altitude_struct my_altitude;

void * display_altitude(void *ptr) 
{
	while(1)
	{
        pthread_mutex_lock(&my_mutex);
        printf("[THREAD 2] Reading data\n");
        printf("[THREAD 2] X:\t\t%f\n", my_altitude.x);
        printf("[THREAD 2] Y:\t\t%f\n", my_altitude.y);
        printf("[THREAD 2] Z:\t\t%f\n", my_altitude.z);
        printf("[THREAD 2] Acc:\t\t%f\n", my_altitude.acceleration);
        printf("[THREAD 2] Roll:\t%f\n", my_altitude.roll);
        printf("[THREAD 2] Pitch:\t%f\n", my_altitude.pitch);
        printf("[THREAD 2] Yaw:\t\t%f\n", my_altitude.yaw);

        clock_gettime(CLOCK_REALTIME, &(my_altitude.time));
        time_t newt = my_altitude.time.tv_sec;
        char * time_now = ctime(&newt);
        printf("[THREAD 2] Timestamp:\t%s\n", time_now);

        pthread_mutex_unlock(&my_mutex);

        sleep(3);
    }
}

void * update_altitude(void *ptr) 
{
	while(1)
	{
        int * k = (int *)ptr;
        int i = *k;

        pthread_mutex_lock(&my_mutex);
       
        my_altitude.x = i;
        my_altitude.y = i+1;
        my_altitude.z = i+2;
        my_altitude.acceleration = i*(i+1);
        my_altitude.roll = 5*i;
        my_altitude.pitch = i*7/(i+2);
        my_altitude.yaw = ((i+2)/(i+1))*3.6;
        clock_gettime(CLOCK_REALTIME, &(my_altitude.time));

        time_t newt = my_altitude.time.tv_sec;
        char * time_now = ctime(&newt);

        printf("[THREAD 1] Updating data\n");
        printf("[THREAD 1] X:\t\t%f\n", my_altitude.x);
        printf("[THREAD 1] Y:\t\t%f\n", my_altitude.y);
        printf("[THREAD 1] Z:\t\t%f\n", my_altitude.z);
        printf("[THREAD 1] Acc:\t\t%f\n", my_altitude.acceleration);
        printf("[THREAD 1] Roll:\t%f\n", my_altitude.roll);
        printf("[THREAD 1] Pitch:\t%f\n", my_altitude.pitch);
        printf("[THREAD 1] Yaw:\t\t%f\n", my_altitude.yaw);
        printf("[THREAD 1] Timestamp:\t%s \n", time_now);
 
        pthread_mutex_unlock(&my_mutex);
        
        sleep(3);
    }
}

int main() 
{
    pthread_t display_thread;
    pthread_t update_thread;
   
    if(pthread_mutex_init(&my_mutex, NULL) != 0)
    {
    	printf("[MAIN] Mutex init failed \n");
    }
    else
    {
    	printf("[MAIN] Mutex init done \n");
    }

    int j =  1;

    if(pthread_create(&display_thread, NULL, display_altitude, NULL) != 0)
    {
    	printf("[MAIN] Display thread creation failed \n");
    }
    else
    {
    	printf("[MAIN] Display thread spawned \n");
    }

    if(pthread_create(&update_thread, NULL, update_altitude, (void *)&j) != 0)
    {
    	printf("[MAIN] Update thread creation failed \n");
    }
    else
    {
    	printf("[MAIN] Update thread spawned \n");
    }

    printf("\n");

    pthread_join(display_thread, NULL);
    pthread_join(update_thread, NULL);

    return 0;
}
